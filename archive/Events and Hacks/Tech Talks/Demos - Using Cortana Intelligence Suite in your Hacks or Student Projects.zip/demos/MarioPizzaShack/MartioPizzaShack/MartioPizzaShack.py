from projectoxford.speech import SpeechClient
sc = SpeechClient("ENTERYOURKEYHERE", gender='Male', locale='en-GB')
from projectoxford.luis import LuisClient
lc = LuisClient("ENTERYOURLUIS HTTP URL")
print = sc.print
input = sc.input
print("Hello, welcome to Mario Pizza Shack")
order=input("How may I help you?")
print("You said:",order) 
intent, toppings,_=lc.query(order)
from projectoxford.speech import join_and
if intent == "Pizza" and toppings:
    print("You will be ordering a", join_and(toppings))  
else:
    print("I am sorry, we only sell Pizza here.")  
  
print("Thank you for visiting Mario Pizza Shack")
