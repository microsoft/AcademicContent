import http.client, urllib.request, urllib.parse, urllib.error, base64

headers = {
   # Basic Authorization Sample
   # 'Authorization': 'Basic %s' % base64.encodestring('{username}:{password}'),
   'Content-type': 'application/json',
}

params = urllib.parse.urlencode({
   # Specify your subscription key
   'subscription-key': 'ENTERYOURKEY',
   # Specify values for optional parameters, as needed
   'language': 'en',
   'detectOrientation ': 'true',
})

try:
   conn = http.client.HTTPSConnection('api.projectoxford.ai')
   conn.request("POST", "/vision/v1/ocr?%s" % params, "{'Url':'http://upload.wikimedia.org/wikipedia/commons/f/f9/Road.sign.arp.750pix.jpg'}", headers)
   response = conn.getresponse()
   data = response.read()
   print(data)
   conn.close()
except Exception as e:
   print("[Errno {0}] {1}".format(e.errno, e.strerror))