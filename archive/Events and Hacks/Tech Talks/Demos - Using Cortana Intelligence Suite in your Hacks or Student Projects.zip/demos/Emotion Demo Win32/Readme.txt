PLEASE DONT NOT SHARE THIS OUTSIDE OF MSFT 
Please edit LiveEmotion.exe.config to include you Cognitive Services API key