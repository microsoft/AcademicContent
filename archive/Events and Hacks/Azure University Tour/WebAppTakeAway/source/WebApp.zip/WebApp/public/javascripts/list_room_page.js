var textAnalysisKey = 'e13faca6e2bc4ff9b4ef95683877ba18';
var idealKeyPhrases = [
	{
        "phrases": ["parking"],
        "advice_missing": "You might want to add parking information.",
        "advice_good": "It's good that you mentioned parking."
    },
	{
        "phrases": ["garden"],
        "advice_missing": "",
        "advice_good": "It's good that you mentioned the garden."
    },
	{
        "phrases": ["rules"],
        "advice_missing": "You might want to mention house rules.",
        "advice_good": "It's good that you mentioned house rules."
    },
	{
        "phrases": ["smoking"],
        "advice_missing": "You might want to add whether or not smoking is allowed.",
        "advice_good": "It's good that you mentioned smoking."
    },
	{
        "phrases": ["bath", "bathroom", "shower"],
        "advice_missing": "You might want to add the number of bathrooms.",
        "advice_good": ""
    },
	{
        "phrases": ["pet", "animal"],
        "advice_missing": "You might want to add whether or not pets are allowed.",
        "advice_good": "It's good that you mentioned pets."
    },
	{
        "phrases": ["children", "kids"],
        "advice_missing": "",
        "advice_good": "It's good that you mentioned children."
    },
    {
        "phrases": ["check-in", "check in"],
        "advice_missing": "You might want to add check-in information.",
        "advice_good": "It's good that you mentioned check-in."
    },
    {
        "phrases": ["check-out", "check out"],
        "advice_missing": "You might want to add check-out information.",
        "advice_good": "It's good that you mentioned check-out."
    }
];

var pricing_data = "";

function CalculatePrice (room_type) {
    jQuery("#listing-occupancy").text(pricing_data[room_type].occupancy + "%");
    jQuery("#day-price").text("$" + pricing_data[room_type].per_night);
    jQuery("#week-price").text("$" + pricing_data[room_type].per_week);
    jQuery("#month-price").text("$" + pricing_data[room_type].per_month);
}

function CreateKeyPhrasesString (keyPhrases) {
    var keyPhrasesString = "";
    for (var i=0; i<keyPhrases.length; i++) {
        keyPhrasesString += keyPhrases[i] + ", ";
    }
    
    return keyPhrasesString.toLowerCase();
}

function GetGoodAdvice (hasKeyPhrases) {
    return idealKeyPhrases[hasKeyPhrases[Math.floor((Math.random() * 100)) % hasKeyPhrases.length]].advice_good;
}

function GetMissingAdvice (missingKeyPhrases) {
    return idealKeyPhrases[missingKeyPhrases[Math.floor((Math.random() * 100)) % missingKeyPhrases.length]].advice_missing;
}

function UpdateListARoom () {
    jQuery("#list-a-property-city").text(settings.city.split(",")[0]);
    
    jQuery.ajax({
        type: "GET",
        url: "/pricingmodel?city=" + settings.city_code,
        headers: {
            'Ocp-Apim-Subscription-Key': cogServicesKey
        }
    }).done(function(data) {
        pricing_data = JSON.parse(data);
        CalculatePrice("1_bedroom");
    }).fail(function (error) {
        console.error(error);  
    });
}

function InitializeListARoom () {
    jQuery("input[type=radio][name=bedroom-radio]").change(function() {
        var option = jQuery(this);
        if (option[0].id == 'bedroom-1') {
	       CalculatePrice("1_bedroom");
        }
        else if (option[0].id == 'bedroom-1-s') {
	       CalculatePrice("1_bedroom_shared");
        }
        else if (option[0].id == 'bedroom-2') {
			CalculatePrice("2_bedroom");
        }
        else if (option[0].id == 'bedroom-2-s') {
			CalculatePrice("2_bedroom_shared");
        }
        else if (option[0].id == 'bedroom-3') {
			CalculatePrice("3_bedroom");
        }
        else if (option[0].id == 'bedroom-3-s') {
			CalculatePrice("3_bedroom_shared");
        }
    });
    
    jQuery("#room-description").change(function() {
        var params = {
            // Request parameters
        };

        var data = {'documents': [
            { 
                'id': '1',
                'language': 'en',
                'text': jQuery(this).val()
            }
        ]};
        
        var description = jQuery(this).val();
      
        jQuery.ajax({
            url: "https://westus.api.cognitive.microsoft.com/text/analytics/v2.0/keyPhrases?" + jQuery.param(params),
            beforeSend: function(xhrObj){
                // Request headers
                xhrObj.setRequestHeader("Content-Type","application/json");
                xhrObj.setRequestHeader("Ocp-Apim-Subscription-Key", textAnalysisKey);
            },
            type: "POST",
            // Request body
            data: JSON.stringify(data),
        })
        .done(function(data) {
            console.log(data);
            if (data.documents.length>0) {
                jQuery("#room-description+br+small+.advice-results").removeClass("warning");
                jQuery("#room-description+br+small+.advice-results").removeClass("error");
                
                var keyPhrases = data.documents[0].keyPhrases;
                var keyPhrasesString = description.toLowerCase();//CreateKeyPhrasesString(keyPhrases);
                var missingKeyPhrases = [];
                var hasKeyPhrases = [];
                var advice_text = "";
                
                for (var i = 0; i<idealKeyPhrases.length; i++) {
                    var phraseMissing = true;
                    for (var p = 0; p<idealKeyPhrases[i].phrases.length; p++) {
                        if (keyPhrasesString.indexOf(idealKeyPhrases[i].phrases[p]) > -1) {
                            phraseMissing = false;
                        }
                    }
                    if (phraseMissing) {
                        missingKeyPhrases.push(i);
                    } else {
                        hasKeyPhrases.push(i);
                    }
                }
                
                
                if (missingKeyPhrases.length > 0) {
                    if (hasKeyPhrases.length > 0) {
                        advice_text += GetGoodAdvice(hasKeyPhrases) + " ";
                    }
                    advice_text += GetMissingAdvice(missingKeyPhrases);
                } else {
                    advice_text = "Your property description looks great!";
                }
                
                jQuery("#room-description+br+small+.advice-results").text(advice_text);
            }
        })
        .fail(function(error) {
            console.error(error);
        });
    });
    
    jQuery("#room-name").change(function() {
        var params = {
            // Request parameters
        };

        var data = {'documents': [
            { 
                'id': '1',
                'language': 'en',
                'text': jQuery(this).val()
            }
        ]};
      
        jQuery.ajax({
            url: "https://westus.api.cognitive.microsoft.com/text/analytics/v2.0/sentiment?" + jQuery.param(params),
            beforeSend: function(xhrObj){
                // Request headers
                xhrObj.setRequestHeader("Content-Type","application/json");
                xhrObj.setRequestHeader("Ocp-Apim-Subscription-Key", textAnalysisKey);
            },
            type: "POST",
            // Request body
            data: JSON.stringify(data),
        })
        .done(function(data) {
            console.log(data);
            if (data.documents.length>0) {
                if (data.documents[0].score <= .2) {
                    // jQuery("#room-name+br+small+.advice-results").addClass("error");
                    jQuery("#room-name+br+small+.advice-results").text('Your property name may be sending the wrong message. We recommend using uplifting adjectives.');
                } else if (data.documents[0].score > .2 && data.documents[0].score < .8) {
                    jQuery("#room-name+br+small+.advice-results").addClass("warning");
                    jQuery("#room-name+br+small+.advice-results").removeClass("error");
                    jQuery("#room-name+br+small+.advice-results").text('We recommend using an uplifting adjective like "cozy" or "clean".');
                } else {
                    jQuery("#room-name+br+small+.advice-results").removeClass("warning");
                    jQuery("#room-name+br+small+.advice-results").removeClass("error");
                    jQuery("#room-name+br+small+.advice-results").text('Your property name looks great!');
                }
            }
        })
        .fail(function(error) {
            console.error(error);
        });
    });
}