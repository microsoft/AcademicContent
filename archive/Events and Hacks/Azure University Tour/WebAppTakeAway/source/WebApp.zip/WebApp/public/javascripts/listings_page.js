var listing_template = '<article>'
                    + '<img src="{{thumbnail}}">'
                    + '<div>'
                    +    '<header>'
                    +        '<h2>{{name}}</h2><h3>{{price}} per night</h3>'
                    +    '</header>'
                    +    '<div><small>{{room_type}} &#183; {{bed}} bed &#183; {{bath}} bath</small></div>'
                    +    '<p>{{description}}</p>'
                    +    '<div>'
                    +        '<div>'
                    +            '<icon class="star{{star1}}"></icon>'
                    +            '<icon class="star{{star2}}"></icon>'
                    +            '<icon class="star{{star3}}"></icon>'
                    +            '<icon class="star{{star4}}"></icon>'
                    +            '<icon class="star{{star5}}"></icon>'
                    +        '</div>'
                    +        '<div class="review">'
                    +            '<icon class="smile"></icon><small>{{number_of_reviews}} Reviews</small>'
                    +        '</div>'
                    +        '<div>'
                    +            '<small><span id="{{id}}-score">Loading</span></small>'
                    +        '</div>'
                    +    '</div>'
                    +'</div>'
                	+'</article>';

var max_listing_score = 1;
var all_listings = [];

function CreateListItem (item) {

	var star1 = item.review_scores_rating < 20 ? " empty" : "";
	var star2 = item.review_scores_rating < 40 ? " empty" : "";
	var star3 = item.review_scores_rating < 60 ? " empty" : "";
	var star4 = item.review_scores_rating < 80 ? " empty" : "";
	var star5 = item.review_scores_rating < 100 ? " empty" : "";

	return jQuery(listing_template.replace('{{thumbnail}}', item.thumbnail_url || "./images/thumbnail.png")
								  .replace('{{name}}', item.name)
								  .replace('{{room_type}}', item.room_type)
								  .replace('{{bed}}', item.beds)
								  .replace('{{bath}}', item.bathrooms)
								  .replace('{{price}}', item.price)
								  .replace('{{description}}', item.description)
								  .replace('{{number_of_reviews}}', item.number_of_reviews)
								  .replace('{{star1}}', star1)
								  .replace('{{star2}}', star2)
								  .replace('{{star3}}', star3)
								  .replace('{{star4}}', star4)
								  .replace('{{star5}}', star5)
								  .replace('{{id}}', item.id)
				);
}


function CreateListings (metadata) {
	
	jQuery("#listings-city").text(settings.city.split(",")[0]);
	jQuery("#listings-neighborhood").text(" " + metadata.neighborhood.split(",")[0]);
	jQuery("#total-listings").text(metadata.listings);
	
	if (metadata.listings < 30) {
		jQuery("#number-of-listings").text(metadata.listings);
	} else {
		jQuery("#number-of-listings").text("30");
	}
	
	var listings_list = jQuery("#listings-list");
	
	listings_list.empty();



	jQuery.ajax({
        type: "GET",
        url: "/listings?city=" + settings.city_code,
        headers: {
            'Ocp-Apim-Subscription-Key': cogServicesKey
        }
    }).done(function(data) {
        all_listings = JSON.parse(data);

		for (var i=0; i<all_listings.length; i++) {
			all_listings[i].id = i;
			all_listings[i].results = {};
			listings_list.append(CreateListItem(all_listings[i]));
			GetListingScore(all_listings[i], category_string);
		}
    }).fail(function (error) {
        console.error(error);  
    });

}


function GetListingScore(listing, category) {

	var url = 'https://cognitivegarage.azure-api.net/BingMaps/NavJoin?startPoint='
		+ listing.latitude + ',' + listing.longitude
		+ '&routeMode=' + settings.route_mode
		+ '&categoryIds=' + category
			// maxTime and maxDistance can be interchanged. (Distance is in km)
		+ (settings.minute_distance ? '&maxTime=' + settings.minute_distance : "")
		+ (settings.distance ? '&maxDistance=' + settings.distance : "");

	jQuery.ajax({
		type: "GET",
		url: url,
		headers: {
			'Ocp-Apim-Subscription-Key': cogServicesKey
		}
	}).done(function(data) {
		var result = data;
		if (result.NavJoinCategoryResults) {
			for (var i = 0; i<result.NavJoinCategoryResults.length; i++) {
				var categoryId = result.NavJoinCategoryResults[i].CategoryId;
				try {
					//The sum of nearby locations for this category becomes this category's score.
					listing.results[categoryId] = result.NavJoinCategoryResults[i].NavJoinEntities.length;
				}
				catch (err) {
					listing.results[categoryId] = 0;
				}
			}
			CalculateListingScore(listing);
		}
	}).fail(function (error) {

		console.error(error);


		// A work around for a 429 error.
		// (429 means there were too many api calls within a given period. This work around waits a second and then tries again.)
		if (error.status == 429) {
			setTimeout(function(){
				GetListingScore(listing, category);
			},1000);
		} else {
			//pin.setOptions({ color: "hsla(0, 96%, 19%, "+ .2 +")" });
			//pin.metadata.description = "<span class='error'>Match Score Error</span>";
			jQuery("#" + listing.id + "-score").text("Perfect Match Unavailable.");
		}

	});
}


function CalculateListingScore(listing) {

	var score = 0;

	var category_results = Object.keys(listing.results);


	for (var i=0; i<category_results.length; i++) {
		//          The number of nearby locations * The priority of those locations (1-3)  * 10
		score += (listing.results[category_results[i]] * settings.categories[category_results[i]].value) * 10;
	}

	listing.score = score;

	max_listing_score = Math.max(max_listing_score, score);

	UpdateListingScore();
}


function UpdateListingScore() {
	for (var i=0; i<all_listings.length; i++) {
		jQuery("#" + i + "-score").text(all_listings[i].score ? Math.round((all_listings[i].score / max_listing_score) * 100) + "% Perfect Match" : "Loading");
	}
}