var express = require('express');
var pricing_model = require('./data_pricing_model');
var listings = require('./data_listings');
var neighborhoods = require('./data_neighborhoods');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/pricingmodel', function(req, res, next) {
  var val = req.query.city;
  if (pricing_model[val]) {
    res.send(JSON.stringify(pricing_model[val]));
  } else {
    res.error("no data for that city");
  }
});

router.get('/listings', function(req, res, next) {
  var val = req.query.city;
  if (listings[val]) {
    res.send(JSON.stringify(listings[val]));
  } else {
    res.error("no data for that city");
  }
});

router.get('/neighborhoods', function(req, res, next) {
  var val = req.query.city;
  if (neighborhoods[val]) {
    res.send(JSON.stringify(neighborhoods[val]));
  } else {
    res.error("no data for that city");
  }
});

module.exports = router;
