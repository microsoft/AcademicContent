 module.exports = {
	"se": {
		"1_bedroom": {
			"occupancy": "68",
			"per_night": "87",
			"per_month": "1767",
			"per_week": "412"
		},
		"1_bedroom_shared": {
			"occupancy": "63",
			"per_night": "51",
			"per_month": "968",
			"per_week": "226"
		},
		"2_bedroom": {
			"occupancy": "66",
			"per_night": "127",
			"per_month": "2511",
			"per_week": "586"
		},
		"2_bedroom_shared": {
			"occupancy": "65",
			"per_night": "111",
			"per_month": "2172",
			"per_week": "507"
		},
		"3_bedroom": {
			"occupancy": "68",
			"per_night": "146",
			"per_month": "2982",
			"per_week": "696"
		},
		"3_bedroom_shared": {
			"occupancy": "61",
			"per_night": "110",
			"per_month": "2006",
			"per_week": "468"
		}
	},
	
	"dc": {
		"1_bedroom": {
			"occupancy": "68",
			"per_night": "96",
			"per_month": "1962",
			"per_week": "458"
		},
		"1_bedroom_shared": {
			"occupancy": "66",
			"per_night": "86",
			"per_month": "1711",
			"per_week": "399"
		},
		"2_bedroom": {
			"occupancy": "66",
			"per_night": "103",
			"per_month": "2043",
			"per_week": "477"
		},
		"2_bedroom_shared": {
			"occupancy": "65",
			"per_night": "95",
			"per_month": "1860",
			"per_week": "434"
		},
		"3_bedroom": {
			"occupancy": "68",
			"per_night": "154",
			"per_month": "3138",
			"per_week": "732"
		},
		"3_bedroom_shared": {
			"occupancy": "67",
			"per_night": "122",
			"per_month": "2444",
			"per_week": "570"
		}
	},
	
	"sf": {
		"1_bedroom": {
			"occupancy": "66",
			"per_night": "155",
			"per_month": "3077",
			"per_week": "718"
		},
		"1_bedroom_shared": {
			"occupancy": "64",
			"per_night": "127",
			"per_month": "2442",
			"per_week": "570"
		},
		"2_bedroom": {
			"occupancy": "66",
			"per_night": "192",
			"per_month": "3794",
			"per_week": "885"
		},
		"2_bedroom_shared": {
			"occupancy": "66",
			"per_night": "179",
			"per_month": "3544",
			"per_week": "827"
		},
		"3_bedroom": {
			"occupancy": "68",
			"per_night": "249",
			"per_month": "5088",
			"per_week": "1187"
		},
		"3_bedroom_shared": {
			"occupancy": "67",
			"per_night": "215",
			"per_month": "4322",
			"per_week": "1008"
		}
	},
	
	"la": {
		"1_bedroom": {
			"occupancy": "64",
			"per_night": "111",
			"per_month": "25127",
			"per_week": "496"
		},
		"1_bedroom_shared": {
			"occupancy": "64",
			"per_night": "91",
			"per_month": "1751",
			"per_week": "409"
		},
		"2_bedroom": {
			"occupancy": "66",
			"per_night": "155",
			"per_month": "3061",
			"per_week": "714"
		},
		"2_bedroom_shared": {
			"occupancy": "66",
			"per_night": "144",
			"per_month": "2859",
			"per_week": "667"
		},
		"3_bedroom": {
			"occupancy": "68",
			"per_night": "232",
			"per_month": "4741",
			"per_week": "1106"
		},
		"3_bedroom_shared": {
			"occupancy": "65",
			"per_night": "128",
			"per_month": "2488",
			"per_week": "581"
		}
	},
	
	"au": {
		"1_bedroom": {
			"occupancy": "68",
			"per_night": "101",
			"per_month": "2056",
			"per_week": "480"
		},
		"1_bedroom_shared": {
			"occupancy": "64",
			"per_night": "60",
			"per_month": "1156",
			"per_week": "270"
		},
		"2_bedroom": {
			"occupancy": "66",
			"per_night": "136",
			"per_month": "2689",
			"per_week": "627"
		},
		"2_bedroom_shared": {
			"occupancy": "66",
			"per_night": "115",
			"per_month": "2269",
			"per_week": "529"
		},
		"3_bedroom": {
			"occupancy": "68",
			"per_night": "195",
			"per_month": "3978",
			"per_week": "928"
		},
		"3_bedroom_shared": {
			"occupancy": "63",
			"per_night": "155",
			"per_month": "2933",
			"per_week": "684"
		}
	}
};