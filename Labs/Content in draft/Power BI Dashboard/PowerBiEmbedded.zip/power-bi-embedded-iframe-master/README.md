---
services: power-bi-embedded
platforms: dotnet
author: dvana
---
# Power BI Embedded - Embed Power BI with an IFrame

This sample shows you essential C# code to use the Power BI Embedded API to integrate a report into a web app.
