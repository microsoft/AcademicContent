function CalculatePrice (price) {
    jQuery("#day-price").text("$" + price);
    jQuery("#week-price").text("$" + (price * 7));
    jQuery("#month-price").text("$" + (price * 30));
}


function InitializeListARoom () {
    CalculatePrice(80);
    jQuery("input[type=radio][name=bedroom-radio]").change(function() {
        var option = jQuery(this);
        if (option[0].id == 'bedroom-1') {
	   CalculatePrice(80);
        }
        else if (option[0].id == 'bedroom-1-s') {
	      CalculatePrice(90);
        }
        else if (option[0].id == 'bedroom-2') {
			CalculatePrice(110);
        }
        else if (option[0].id == 'bedroom-2-s') {
			CalculatePrice(145);
        }
        else if (option[0].id == 'bedroom-3') {
			CalculatePrice(200);
        }
        else if (option[0].id == 'bedroom-3-s') {
			CalculatePrice(230);
        }
    });
}