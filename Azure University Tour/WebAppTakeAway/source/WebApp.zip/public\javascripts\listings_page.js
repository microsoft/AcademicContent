var listing_template = '<article>'
                    + '<img src="{{thumbnail}}">'
                    + '<div>'
                    +    '<header>'
                    +        '<h2>{{name}}</h2><h3>{{price}} per night</h3>'
                    +    '</header>'
                    +    '<div><small>{{room_type}} &#183; {{bed}} bed &#183; {{bath}} bath</small></div>'
                    +    '<p>{{description}}</p>'
                    +    '<div>'
                    +        '<div>'
                    +            '<icon class="star{{star1}}"></icon>'
                    +            '<icon class="star{{star2}}"></icon>'
                    +            '<icon class="star{{star3}}"></icon>'
                    +            '<icon class="star{{star4}}"></icon>'
                    +            '<icon class="star{{star5}}"></icon>'
                    +        '</div>'
                    +        '<div class="review">'
                    +            '<icon class="smile"></icon><small>{{number_of_reviews}} Reviews</small>'
                    +        '</div>'
                    +        '<div>'
                    +            '<small>85% Perfect Match</small>'
                    +        '</div>'
                    +    '</div>'
                    +'</div>'
                	+'</article>';

function CreateListItem (item) {

	var star1 = item.review_scores_rating < 20 ? " empty" : "";
	var star2 = item.review_scores_rating < 40 ? " empty" : "";
	var star3 = item.review_scores_rating < 60 ? " empty" : "";
	var star4 = item.review_scores_rating < 80 ? " empty" : "";
	var star5 = item.review_scores_rating < 100 ? " empty" : "";

	return jQuery(listing_template.replace('{{thumbnail}}', item.thumbnail_url || "/images/clear.gif")
								  .replace('{{name}}', item.name)
								  .replace('{{room_type}}', item.room_type)
								  .replace('{{bed}}', item.beds)
								  .replace('{{bath}}', item.bathrooms)
								  .replace('{{price}}', item.price)
								  .replace('{{description}}', item.description)
								  .replace('{{number_of_reviews}}', item.number_of_reviews)
								  .replace('{{star1}}', star1)
								  .replace('{{star2}}', star2)
								  .replace('{{star3}}', star3)
								  .replace('{{star4}}', star4)
								  .replace('{{star5}}', star5)
				);
}


function CreateListings () {
	var listings_list = jQuery("#listings-list");

	for (var i=0; i<data_listings.length; i++) {
		listings_list.append(CreateListItem(data_listings[i]));
	}
}